<?php
$link = new mysqli("localhost", "root", "", "test");
if ($link->connect_error) {
    die("Erreur de connexion : " . $link->connect_error);
}
?>