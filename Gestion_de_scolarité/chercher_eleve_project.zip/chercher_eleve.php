<?php
session_start();
include('cadre.php');
include('connexion.php');

if (isset($_SESSION['admin']) || isset($_SESSION['etudiant']) || isset($_SESSION['prof'])) {
    echo '<div class="corp">';
    echo '<img src="titre_img/cherche_eleve.png" class="position_titre"><center>';

    if (isset($_GET['cherche_eleve'])) {
        $classes = mysqli_query($link, "SELECT DISTINCT nom FROM classe");
        $promos = mysqli_query($link, "SELECT DISTINCT promotion FROM classe ORDER BY promotion DESC");
        ?>
        <form action="chercher_eleve.php" method="post" class="formulaire">
            <fieldset>
                <legend>Critère de recherche</legend>
                <label>Nom :</label>
                <input type="text" name="nomel"><br><br>

                <label>Prénom :</label>
                <input type="text" name="prenomel"><br><br>

                <label>Promotion :</label>
                <select name="promotion">
                    <option value="">Choisir la promotion</option>
                    <?php while ($p = mysqli_fetch_assoc($promos)) {
                        echo '<option value="' . htmlspecialchars($p['promotion']) . '">' . htmlspecialchars($p['promotion']) . '</option>';
                    } ?>
                </select><br><br>

                <label>Classe :</label>
                <select name="nomcl">
                    <option value="">Choisir la classe</option>
                    <?php while ($c = mysqli_fetch_assoc($classes)) {
                        echo '<option value="' . htmlspecialchars($c['nom']) . '">' . htmlspecialchars($c['nom']) . '</option>';
                    } ?>
                </select><br><br>

                <center><input type="submit" name="submit" value="Rechercher"></center>
            </fieldset>
        </form>
        <a href="index.php">Revenir à la page principale !</a>
        <?php
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
        $nomel = trim($_POST['nomel']);
        $prenomel = trim($_POST['prenomel']);
        $nomcl = trim($_POST['nomcl']);
        $promo = trim($_POST['promotion']);

        $query = "
            SELECT eleve.*, classe.nom AS classe_nom, classe.promotion
            FROM eleve 
            INNER JOIN classe ON classe.codecl = eleve.codecl
            WHERE eleve.nomel LIKE ? AND eleve.prenomel LIKE ?
        ";
        $params = [];
        $types = "ss";
        $params[] = '%' . $nomel . '%';
        $params[] = '%' . $prenomel . '%';

        if (!empty($nomcl) && empty($promo)) {
            $query .= " AND classe.nom = ?";
            $types .= "s";
            $params[] = $nomcl;
        } elseif (!empty($promo) && empty($nomcl)) {
            $query .= " AND classe.promotion = ?";
            $types .= "s";
            $params[] = $promo;
        } elseif (!empty($promo) && !empty($nomcl)) {
            $query .= " AND classe.nom = ? AND classe.promotion = ?";
            $types .= "ss";
            $params[] = $nomcl;
            $params[] = $promo;
        }

        $stmt = mysqli_prepare($link, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, $types, ...$params);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) > 0) {
                echo '<table border="1" cellpadding="10" cellspacing="0"><thead><tr>
                    <th>Nom</th><th>Prénom</th><th>Adresse</th><th>Date de naissance</th>
                    <th>Téléphone</th><th>Classe</th><th>Promotion</th></tr></thead><tbody>';
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>
                        <td>' . htmlspecialchars($row['nomel']) . '</td>
                        <td>' . htmlspecialchars($row['prenomel']) . '</td>
                        <td>' . htmlspecialchars($row['adresse']) . '</td>
                        <td>' . htmlspecialchars($row['date_naissance']) . '</td>
                        <td>' . htmlspecialchars($row['telephone']) . '</td>
                        <td>' . htmlspecialchars($row['classe_nom']) . '</td>
                        <td>' . htmlspecialchars($row['promotion']) . '</td>
                    </tr>';
                }
                echo '</tbody></table>';
            } else {
                echo "<p>Aucun élève trouvé avec les critères fournis.</p>";
            }
            mysqli_stmt_close($stmt);
        } else {
            echo "Erreur lors de la préparation de la requête.";
        }

        echo '<br><a href="chercher_eleve.php?cherche_eleve=true">Revenir à la page précédente !</a>';
    }

    echo '</center></div>';
} else {
    echo "<p>Accès non autorisé.</p>";
}
?>